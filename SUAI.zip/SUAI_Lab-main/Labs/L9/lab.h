#pragma once

#include "stdio.h"
#include "stdlib.h"

unsigned int invert_4(unsigned int N);