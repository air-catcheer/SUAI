
OneRowMatrix; отличия от 1 (основного задания):

1.В матрице все строки одинаковые;

2.Добавить два класса исключений SumMatrixException и ProductMatrixException

3.Пакеты: com.mycompany
