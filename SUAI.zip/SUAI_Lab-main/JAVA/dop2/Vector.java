package dop2;

import java.util.Arrays;

public class Vector {
    private double[] vector;

    public Vector(double[] vector) {
        this.vector = vector;
    }

    public double[] getVector() {
        return vector;
    }

    public void setVector(double[] vector) {
        this.vector = vector;
    }
}
