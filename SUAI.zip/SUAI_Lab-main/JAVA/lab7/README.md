Реализуйте класс для хранения настроек Settings, в котором хранятся пары «имя параметра, значение». «Имя параметра» задается строкой, а «значение» целым числом.
Реализация должна использовать класс HashMap. 

В классе Settings должны быть определены:

* toString() и equals()
 
* put(String, int)

* int get(String)

* delete(String)

* loadFromBinaryFile(String filename)

* saveToBinaryFile(String filename)

* loadFromTextFile(String filename)

* saveToTextFile(String filename)
