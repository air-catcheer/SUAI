package dop5;

public class Node {
    public Object element;
    public Node next;

    public Node(Object element) {
        this.element = element;
        next = null;
    }
}

